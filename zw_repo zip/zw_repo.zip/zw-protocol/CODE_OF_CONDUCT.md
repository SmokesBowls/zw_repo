# Code of Conduct

- Be excellent to each other.
- No harassment, doxxing, or hate speech.
- Technical debates are welcome; personal attacks are not.
- Violations may result in PR closure or bans.
